# ProgPOE Part 1
//Welcome to my Recipe project
in this project we focused on taking a users inputof a recipe and all of the ingredients and quantities of the ingredients
the program was made so that a user may write a recipe, enter the ingredients and the amount of ingredients and then either diplay set recipe 
or scale it by the factor of 0.5, 2 or 3. 
When the program is run, the user will be prompted to enter the recipe details, it will then ask for the ingredients and the steps
that are needed to be taken to create set dish. once the recipe is fully written, the user is able to either display the recipe with thr program, 
scale it by the factor of 0.5, 2, or 3. the other choices are to clear the quntities of the ingrediants or to either 
clear the recipe as a whole. 
# _________________________________________________________________________________________________________________________________________________________________________________

# ProgPOE Part 2
Note
# When trying to enter a choice, if it does not recognize you inoutting a key, try left clck anywhere on  the black box of the app

# Menu Options

# Enter a New Recipe (Option 1):

Allows you to enter details for a new recipe, including the name, ingredients, and steps.

# Display All Recipes (Option 2):

Shows a list of all recipes sorted alphabetically by name.
For each recipe, it displays the name, ingredients, and steps.

# Select Recipe by Name (Option 3):

Enables you to choose a specific recipe by entering its name.
Once selected, you can view the details of the chosen recipe.

# Exit (Option 4):

Terminates the application.
Additional Features

# Scaling Recipe:

You can scale the quantities of ingredients in a recipe by a specified factor (0.5, 2, or 3).
Scaling can be performed in the "Manage Recipe" menu after selecting a recipe.

# Resetting All Quantities:

Allows you to reset all ingredient quantities in a recipe to their original values (assuming original values are 1 for each ingredient).
Accessible in the "Manage Recipe" menu after selecting a recipe.

# Clearing a Recipe:

Provides an option to clear all details of a recipe, effectively removing it.
This operation can also be found in the "Manage Recipe" menu after selecting a recipe.

# Calorie Notification:

If the total calories of a recipe exceed 300 after scaling, the app will notify you with a warning message.

# This code was written by 
# Jared Allen
# Student Number: ST10271869
# Module Code: PROG6122

# Github Link

